package util;

public class GenericException extends Exception {

	public GenericException() {
		super();
	}

	public GenericException(String arg0) {
		super(arg0);
	}

	
}
